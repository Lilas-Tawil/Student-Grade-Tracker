import java.util.*;

public class Task1 {
	
	public static void main (String []args) {
		
	ArrayList<Integer> grades= new ArrayList<Integer>();
	Scanner scan=new Scanner (System.in);
	
	System.out.println("Enter grade of student 1 over 100 (enter q to quit)");
	int grade= scan.nextInt();
	
	if (grade >=0 && grade <=100) {
	grades.add(grade);}
	int j=2;
	
	while(grade >=0 && grade <=100) {
	
     	System.out.println("Enter grade of student" +j+ "(enter any # out of the range 0-100 to quit)");
		 grade= scan.nextInt();
		if (grade >=0 && grade <=100) {
            grades.add(grade);
            j++;
	}
         else {
		break;
		}
	}
	
           
	System.out.println("THe average of the class is: " +avg(grades)) ;
	System.out.println("THe minimum grade in the class is: " +min(grades)) ;
	System.out.println("THe maximum grade in the class is: " +max(grades)) ;
        }
	
	
public static int avg(List<Integer> grades){
	int sum=0;
	int size=grades.size();
	
	
	for(int grade:grades) {
		sum+=grade;
	}
	int avg=sum/size;
	return avg; 
}
public static int min(List<Integer> grades){
	Collections.sort(grades);
	int min = grades.get(0);
	return min; 
}
public static int max(List<Integer> grades){
	Collections.sort(grades);
	int max = grades.get(grades.size()-1);
	return max; 
}

}